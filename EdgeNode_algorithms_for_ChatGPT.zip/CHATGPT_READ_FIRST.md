# EdgeNode 통합 코드 검토 안내

현재 control 브랜치의 로컬 미커밋 통합 코드 스냅샷입니다. 먼저 docs/control_integration.md를 읽고 ros2_ws/src/edgenode_bringup/launch/autonomy.launch.py에서 시작해 perception → planning → control 순서로 검토하세요.

Docker/ROS2/DDS 설정을 유지하며 한성이 OpenCV 인지를 통합했습니다. 기존 인지 구현은 주석으로 보존돼 있으며 lane_opencv_pkg는 비활성입니다. 지도는 local_data/c_track_mgeo에 포함돼 있습니다. 위치는 MORAI EgoVehicleStatus local ENU를 사용합니다.

빌드·설치 생성물, 센서 캡처, 주행 로그 및 Git 이력은 제외했습니다. 한성이 read-only 참조 저장소 전체는 포함하지 않았으며 통합 결과와 비교 문서만 제공합니다. 문서의 실제 주행 통계는 원시 로그 없이 문서에 기록된 결과입니다.

검토할 항목: 차선 추적, 지도 링크 선택/pure pursuit, LiDAR swept corridor, 장애물 STOP, 조향 부호, 속도 PID, 각 stream watchdog, 주행 시간 제한, tests. 모든 코스의 안전이나 최적성을 보장하는 코드로 가정하지 마세요.
